#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ESP32Servo.h>
#include <HTTPClient.h>

// ParkSense
// Sensors + LEDs + Servo + Buzzer
// WiFi + HiveMQ Cloud MQTT


// WIFI

const char* ssid = "Wokwi-GUEST";
const char* password = "";


// HIVEMQ CLOUD

const char* mqttServer =
  "528aad060bf74899aa4dc3f233701720.s1.eu.hivemq.cloud";

const int mqttPort = 8883;


const char* mqttUsername = "ParkSensev2";
const char* mqttPassword = "MY HIVEMQ PASSWORD";


// Unique client name
const char* mqttClientName =
  "ParkSense-ESP32";


// Secure WiFi connection
WiFiClientSecure wifiClient;

PubSubClient mqttClient(wifiClient);

// ThingSpeak
const char* thingSpeakAPIKey = "MY API KEY";

unsigned long lastThingSpeakUpload = 0;
const unsigned long thingSpeakInterval = 20000; 

// BAY 1 SENSOR

const int trig1 = 5;
const int echo1 = 18;


// BAY 2 SENSOR

const int trig2 = 19;
const int echo2 = 21;


// ENTRANCE SENSOR

const int entranceTrig = 32;
const int entranceEcho = 33;


// BAY 1 LEDs


const int green1 = 25;
const int red1 = 26;


// BAY 2 LEDs

const int green2 = 27;
const int red2 = 14;


// SERVO

Servo barrierServo;

const int servoPin = 13;


// BUZZER

const int buzzerPin = 23;


// DISTANCE SETTINGS

const float occupiedDistance = 10.0;

const float entranceDistance = 10.0;

// EDGE INTELLIGENCE
const int readingsNeeded = 3;

int bay1DetectionCount = 0;
int bay2DetectionCount = 0;

bool bay1Occupied = false;
bool bay2Occupied = false;

// CONNECT TO WIFI

void connectWiFi() {

  Serial.print("Connecting to WiFi");

  WiFi.begin(ssid, password);


  while (WiFi.status() != WL_CONNECTED) {

    delay(500);

    Serial.print(".");
  }


  Serial.println();

  Serial.println("WiFi connected!");

  Serial.print("IP Address: ");

  Serial.println(WiFi.localIP());
}


// CONNECT TO HIVEMQ

void connectMQTT() {

  while (!mqttClient.connected()) {

    Serial.print("Connecting to HiveMQ Cloud...");


    if (mqttClient.connect(
          mqttClientName,
          mqttUsername,
          mqttPassword)) {

      Serial.println("CONNECTED!");

    }

    else {

      Serial.print("FAILED! MQTT state: ");

      Serial.println(mqttClient.state());

      Serial.println(
        "Trying again in 3 seconds..."
      );

      delay(3000);
    }
  }
}


// SETUP

void setup() {

  Serial.begin(115200);


  // WIFI

  connectWiFi();


  // SECURE MQTT

 

  wifiClient.setInsecure();


  mqttClient.setServer(
    mqttServer,
    mqttPort
  );


  connectMQTT();


  // ULTRASONIC SENSORS

  pinMode(trig1, OUTPUT);
  pinMode(echo1, INPUT);

  pinMode(trig2, OUTPUT);
  pinMode(echo2, INPUT);

  pinMode(entranceTrig, OUTPUT);
  pinMode(entranceEcho, INPUT);


  // LEDs

  pinMode(green1, OUTPUT);
  pinMode(red1, OUTPUT);

  pinMode(green2, OUTPUT);
  pinMode(red2, OUTPUT);


  // BUZZER

  pinMode(buzzerPin, OUTPUT);

  noTone(buzzerPin);


  // SERVO

  barrierServo.attach(servoPin);

  // Barrier starts closed
  barrierServo.write(0);


  Serial.println();

  Serial.println(
    "=============================="
  );

  Serial.println(
    "ParkSense System Started"
  );

  Serial.println(
    "=============================="
  );
}


// MAIN LOOP

void sendToThingSpeak(int availableSpaces, bool bay1Occupied, bool bay2Occupied) {

  if (WiFi.status() == WL_CONNECTED) {

    HTTPClient http;

    String url = "https://api.thingspeak.com/update?api_key=";
    url += thingSpeakAPIKey;

    // Field 1 = Available Spaces
    url += "&field1=";
    url += String(availableSpaces);

    // Field 2 = Bay 1
    // 0 = AVAILABLE, 1 = OCCUPIED
    url += "&field2=";
    url += String(bay1Occupied ? 1 : 0);

    // Field 3 = Bay 2
    // 0 = AVAILABLE, 1 = OCCUPIED
    url += "&field3=";
    url += String(bay2Occupied ? 1 : 0);

    http.begin(url);

    int httpResponseCode = http.GET();

    if (httpResponseCode > 0) {
      Serial.print("ThingSpeak response: ");
      Serial.println(httpResponseCode);
    } else {
      Serial.print("ThingSpeak error: ");
      Serial.println(httpResponseCode);
    }

    http.end();
  }
}

void loop() {


  // CHECK WIFI

  if (WiFi.status() != WL_CONNECTED) {

    connectWiFi();
  }


  // CHECK MQTT

  if (!mqttClient.connected()) {

    connectMQTT();
  }


  mqttClient.loop();


  // READ SENSORS

  float distance1 =
    getDistance(trig1, echo1);


  delay(50);


  float distance2 =
    getDistance(trig2, echo2);


  delay(50);


  float entrance =
    getDistance(
      entranceTrig,
      entranceEcho
    );



// EDGE INTELLIGENCE - OCCUPANCY DETECTION


// BAY 1
if (distance1 < occupiedDistance) {

  bay1DetectionCount++;

  if (bay1DetectionCount >= readingsNeeded) {
    bay1Occupied = true;
    bay1DetectionCount = readingsNeeded;
  }

}
else {

  bay1DetectionCount = 0;
  bay1Occupied = false;

}


// BAY 2
if (distance2 < occupiedDistance) {

  bay2DetectionCount++;

  if (bay2DetectionCount >= readingsNeeded) {
    bay2Occupied = true;
    bay2DetectionCount = readingsNeeded;
  }

}
else {

  bay2DetectionCount = 0;
  bay2Occupied = false;

}

Serial.print("Bay 1 Detection Count: ");
Serial.print(bay1DetectionCount);

Serial.print(" | Bay 2 Detection Count: ");
Serial.println(bay2DetectionCount);

Serial.print("Bay 1 Status: ");

if (bay1Occupied) {
  Serial.print("OCCUPIED");
}
else if (bay1DetectionCount > 0) {
  Serial.print("POSSIBLE VEHICLE");
}
else {
  Serial.print("AVAILABLE");
}

Serial.print(" | Bay 2 Status: ");

if (bay2Occupied) {
  Serial.println("OCCUPIED");
}
else if (bay2DetectionCount > 0) {
  Serial.println("POSSIBLE VEHICLE");
}
else {
  Serial.println("AVAILABLE");
}

  bool carAtEntrance =
    entrance < entranceDistance;


  // BAY 1 LED
 
  if (bay1Occupied) {

    digitalWrite(red1, HIGH);

    digitalWrite(green1, LOW);

  }

  else {

    digitalWrite(red1, LOW);

    digitalWrite(green1, HIGH);
  }


  // BAY 2 LED

  if (bay2Occupied) {

    digitalWrite(red2, HIGH);

    digitalWrite(green2, LOW);

  }

  else {

    digitalWrite(red2, LOW);

    digitalWrite(green2, HIGH);
  }


  // AVAILABLE SPACES

  int availableSpaces = 2;


  if (bay1Occupied) {

    availableSpaces--;
  }


  if (bay2Occupied) {

    availableSpaces--;
  }


  // BARRIER + BUZZER

  bool barrierOpen = false;


  // Car present AND parking available

  if (
    carAtEntrance &&
    availableSpaces > 0
  ) {

    barrierServo.write(90);

    noTone(buzzerPin);

    barrierOpen = true;
  }


  // Car present BUT parking full

  else if (
    carAtEntrance &&
    availableSpaces == 0
  ) {

    barrierServo.write(0);

    tone(buzzerPin, 1000);

    barrierOpen = false;
  }


  // No car at entrance

  else {

    barrierServo.write(0);

    noTone(buzzerPin);

    barrierOpen = false;
  }


  // SERIAL MONITOR

  Serial.print("Bay 1: ");


  if (bay1Occupied) {

    Serial.print("OCCUPIED");

  }

  else {

    Serial.print("AVAILABLE");
  }


  Serial.print(" | Bay 2: ");


  if (bay2Occupied) {

    Serial.print("OCCUPIED");

  }

  else {

    Serial.print("AVAILABLE");
  }


  Serial.print(" | Spaces: ");

  Serial.print(availableSpaces);


  Serial.print(" | Entrance: ");


  if (carAtEntrance) {

    Serial.print("CAR DETECTED");

  }

  else {

    Serial.print("CLEAR");
  }


  Serial.print(" | Barrier: ");


  if (barrierOpen) {

    Serial.print("OPEN");

  }

  else {

    Serial.print("CLOSED");
  }


  Serial.print(" | Buzzer: ");


  if (
    carAtEntrance &&
    availableSpaces == 0
  ) {

    Serial.println("ON");

  }

  else {

    Serial.println("OFF");
  }



  // SEND DATA TO HIVEMQ

 // ---------- BAY 1 ----------

if (bay1Occupied) {

  mqttClient.publish(
    "parksense/darby/bay1",
    "OCCUPIED"
  );

}
else if (bay1DetectionCount > 0) {

  mqttClient.publish(
    "parksense/darby/bay1",
    "POSSIBLE VEHICLE"
  );

}
else {

  mqttClient.publish(
    "parksense/darby/bay1",
    "AVAILABLE"
  );

}


  // ---------- BAY 2 ----------

  // ---------- BAY 2 ----------

if (bay2Occupied) {

  mqttClient.publish(
    "parksense/darby/bay2",
    "OCCUPIED"
  );

}
else if (bay2DetectionCount > 0) {

  mqttClient.publish(
    "parksense/darby/bay2",
    "POSSIBLE VEHICLE"
  );

}
else {

  mqttClient.publish(
    "parksense/darby/bay2",
    "AVAILABLE"
  );

}

  // ---------- AVAILABLE SPACES ----------

  char spacesText[10];


  sprintf(
    spacesText,
    "%d",
    availableSpaces
  );


  mqttClient.publish(
    "parksense/darby/spaces",
    spacesText
  );


  // ---------- ENTRANCE ----------

  if (carAtEntrance) {

    mqttClient.publish(
      "parksense/darby/entrance",
      "CAR DETECTED"
    );

  }

  else {

    mqttClient.publish(
      "parksense/darby/entrance",
      "CLEAR"
    );
  }


  // ---------- BARRIER ----------

  if (barrierOpen) {

    mqttClient.publish(
      "parksense/darby/barrier",
      "OPEN"
    );

  }

  else {

    mqttClient.publish(
      "parksense/darby/barrier",
      "CLOSED"
    );
  }


  // ---------- BUZZER ----------

  if (
    carAtEntrance &&
    availableSpaces == 0
  ) {

    mqttClient.publish(
      "parksense/darby/buzzer",
      "ON"
    );

  }

  else {

    mqttClient.publish(
      "parksense/darby/buzzer",
      "OFF"
    );
  }


  Serial.println(
    "Data sent to HiveMQ Cloud!"
  );

  Serial.println(
    "------------------------------"
  );

if (millis() - lastThingSpeakUpload >= thingSpeakInterval) {

  sendToThingSpeak(
    availableSpaces,
    bay1Occupied,
    bay2Occupied
  );

  lastThingSpeakUpload = millis();
}
  delay(2000);
}


// ULTRASONIC DISTANCE FUNCTION


float getDistance(
  int trigPin,
  int echoPin
) {

  digitalWrite(
    trigPin,
    LOW
  );


  delayMicroseconds(2);


  digitalWrite(
    trigPin,
    HIGH
  );


  delayMicroseconds(10);


  digitalWrite(
    trigPin,
    LOW
  );


  long duration =
    pulseIn(
      echoPin,
      HIGH
    );


  float distance =
    duration * 0.034 / 2;


  return distance;
}